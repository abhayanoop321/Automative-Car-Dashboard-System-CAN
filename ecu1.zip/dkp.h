/* 
 * File:   dkp.h
 * Author: abhay
 *
 * Created on 28 April, 2026, 5:51 PM
 */

#ifndef DKP_H
#define	DKP_H

#define LEVEL 0
#define STATE_CHANGE 1

#define KEY_PORT PORTC

#define SWITCH1 0x01
#define SWITCH2 0x02
#define SWITCH3 0x04
#define SWITCH4 0x08

#define ALL_RELEASE 0x00
#define INPUT_PINS 0x0F

void init_digital_keypad(void);
unsigned char read_digital_keypad(unsigned char detection_type);

#endif	/* DKP_H */

