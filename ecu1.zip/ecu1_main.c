/*
 * File:   ecu1_main.c
 * Author: abhay
 *
 * Created on 28 April, 2026, 5:52 PM
 */


#include <xc.h>
#include "ecu1_sensor.h"
#include "adc.h"
#include "dkp.h"
#include "uart.h"
#include "can.h"
#include "msg_id.h"
#define _XTAL_FREQ 8000000

void init_config(void){
    init_can();
    init_adc();
    init_digital_keypad();
    //init_uart();
    puts("START\n\r");
}
void speed_to_string(unsigned char *res, int speed){
    if (speed > 100) speed = 100;
    if (speed < 0) speed = 0;   
    
    if(speed == 100){
        res[0] = '1';
        res[1] = '0';
        res[2] = '0';
        res[3] = '\0';
        return;
    }
    if(speed >= 10){
        res[0] = '0' + (speed / 10);
        res[1] = '0' + (speed % 10);
        res[2] = '\0';
    }
    else{
        res[0] = '0' + speed;
        res[1] = '\0';
    }
}

void main(void){
    init_config();
    uint16_t speed;
    unsigned char speeds[4];
    unsigned char gear;
    while(1){
        gear = get_gear_pos();
        speed = get_speed();
        speed_to_string(speeds, speed);
        can_transmit(SPEED_MSG_ID, speeds, 3);
        __delay_ms(50);
        can_transmit(GEAR_MSG_ID, &gear, 2);
        __delay_ms(50);
    }
}
