/* 
 * File:   msg_id.h
 * Author: abhay
 *
 * Created on 30 April, 2026, 4:16 PM
 */

#ifndef MSG_ID_H
#define	MSG_ID_H

#define SPEED_MSG_ID 0x10
#define GEAR_MSG_ID 0x20

#endif	/* MSG_ID_H */

