/* 
 * File:   uart.h
 * Author: abhay
 *
 * Created on 29 April, 2026, 4:14 PM
 */

#ifndef UART_H
#define	UART_H

#define RX_PIN					TRISC7
#define TX_PIN					TRISC6

void init_uart(void);
void putch(unsigned char data);
void puts(unsigned char *data);


#endif	/* UART_H */

