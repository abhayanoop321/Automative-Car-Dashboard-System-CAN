/*
 * File:   ecu1_sensor.c
 * Author: abhay
 *
 * Created on 28 April, 2026, 5:52 PM
 */


#include <xc.h>
#include "ecu1_sensor.h"
#include "adc.h"
#include "dkp.h"

uint16_t get_speed(){
    // Implement the speed function
    unsigned short speed = read_adc(CHANNEL4);
    return speed / 10.23;
}

unsigned char get_gear_pos(){
    // Implement the gear function
    static unsigned char gear_pos = 'N';
    unsigned char key = read_digital_keypad(STATE_CHANGE);
    if(key == SWITCH1){
        for(int i = 0; i < 15000; i++);
        if(gear_pos == 'N'){
            gear_pos = '1';
        }
        else if(gear_pos == '1'){
            gear_pos = '2';
        }
        else if(gear_pos == '2'){
            gear_pos = '3';
        }
        else if(gear_pos == '3'){
            gear_pos = '4';
        }
        else if(gear_pos == '4'){
            gear_pos = '5';
        }
        else if(gear_pos == '5'){
            gear_pos = 'R';
        }
    }
    else if(key == SWITCH2){
        for(int i = 0; i < 15000; i++);
        if(gear_pos == 'R'){
            gear_pos = '5';
        }
        else if(gear_pos == '5'){
            gear_pos = '4';
        }
        else if(gear_pos == '4'){
            gear_pos = '3';
        }
        else if(gear_pos == '3'){
            gear_pos = '2';
        }
        else if(gear_pos == '2'){
            gear_pos = '1';
        }
        else if(gear_pos == '1'){
            gear_pos = 'N';
        }
    }
    else if(key == SWITCH3){
        gear_pos = 'N';
    }
    else if(key == SWITCH4){
        gear_pos = 'R';
    }
    return gear_pos;
}
