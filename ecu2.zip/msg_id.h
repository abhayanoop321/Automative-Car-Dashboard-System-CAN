/* 
 * File:   msg_id.h
 * Author: abhay
 *
 * Created on 6 May, 2026, 4:47 PM
 */

#ifndef MSG_ID_H
#define	MSG_ID_H

#define RPM_MSG_ID 0x30
#define INDICATOR_MSG_ID 0x50

#endif	/* MSG_ID_H */

