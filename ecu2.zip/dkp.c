/*
 * File:   dkp.c
 * Author: abhay
 *
 * Created on 6 May, 2026, 3:13 PM
 */


#include <xc.h>
#include "dkp.h"

void init_digital_keypad(void){
    TRISC |= INPUT_PINS;
}

unsigned char read_digital_keypad(unsigned char detection_type){
    static unsigned char once = 1;
    unsigned char key = (~KEY_PORT) & INPUT_PINS;
    if(detection_type == STATE_CHANGE){
        if((key != ALL_RELEASE) && once){
            once = 0;
            return key;
        }
        else if(key == ALL_RELEASE){
            once = 1;
        }
    }
    else if(detection_type == LEVEL){
        return key;
    }
    return ALL_RELEASE;
}