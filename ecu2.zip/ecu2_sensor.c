/*
 * File:   ecu2_sensor.c
 * Author: abhay
 *
 * Created on 6 May, 2026, 3:12 PM
 */


#include <xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "dkp.h"

unsigned char *my_strcpy(unsigned char *dest, const unsigned char *src) {
    unsigned char *orig = dest;

    while ((*dest++ = *src++) != '\0');

    return orig;
}

uint16_t get_rpm(){
    // Implement the rmp function
    unsigned short rpm = read_adc(CHANNEL4);
    return rpm * 2.5415;
}

unsigned char *get_indicator_stat(void) {
    static unsigned char indicator_stat[6];
    unsigned char key = read_digital_keypad(STATE_CHANGE);

    if (key == SWITCH1) {
        for (int i = 0; i < 15000; i++);
        my_strcpy(indicator_stat, (const unsigned char *)"<-   ");
    }
    else if (key == SWITCH2) {
        for (int i = 0; i < 15000; i++);
        my_strcpy(indicator_stat, (const unsigned char *)"     ");
    }
    else if (key == SWITCH3) {
        my_strcpy(indicator_stat, (const unsigned char *)"   ->");
    }
    else if (key == SWITCH4) {
        my_strcpy(indicator_stat, (const unsigned char *)"<- ->");
    }
    return indicator_stat;
}
