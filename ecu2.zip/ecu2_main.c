/*
 * File:   ecu2_main.c
 * Author: abhay
 *
 * Created on 6 May, 2026, 3:14 PM
 */


#include <xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "dkp.h"
#include "uart.h"
#include "can.h"
#include "msg_id.h"
#define _XTAL_FREQ 8000000

void init_config(void){
    init_can;
    init_adc();
    init_digital_keypad();
    //init_uart();
    puts("START\n\r");
}
void rpm_to_string(unsigned char *res, int rpm){
    if (rpm > 2600) rpm = 2600;
    if (rpm < 0) rpm = 0;         

    if (rpm >= 1000) {
        res[0] = '0' + (rpm / 1000);
        res[1] = '0' + ((rpm / 100) % 10);
        res[2] = '0' + ((rpm / 10) % 10);
        res[3] = '0' + (rpm % 10);
        res[4] = '\0';
    }
    else if (rpm >= 100) {
        res[0] = '0' + (rpm / 100);
        res[1] = '0' + ((rpm / 10) % 10);
        res[2] = '0' + (rpm % 10);
        res[3] = '\0';
    }
    else if (rpm >= 10) {
        res[0] = '0' + (rpm / 10);
        res[1] = '0' + (rpm % 10);
        res[2] = '\0';
    }
    else {
        res[0] = '0' + rpm;
        res[1] = '\0';
    }
}

void main(void){
    init_config();
    uint16_t rpm;
    unsigned char rpms[5];
    unsigned char indicator[6];
    while(1){
        my_strcpy(indicator, get_indicator_stat());
        rpm = get_rpm();
        rpm_to_string(rpms, rpm);
        //puts(indicator);
        //puts("  ");        
        //puts("RPM = ");
        //puts(rpms);
        //puts("\n\r");
        can_transmit(RPM_MSG_ID, rpms, 5);
        __delay_ms(50);
        can_transmit(INDICATOR_MSG_ID, indicator, 6);
    }
}