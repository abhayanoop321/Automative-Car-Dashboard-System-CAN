/* 
 * File:   ecu2_sensor.h
 * Author: abhay
 *
 * Created on 6 May, 2026, 3:12 PM
 */

#ifndef ECU2_SENSOR_H
#define	ECU2_SENSOR_H

#include <stdint.h>
#include "dkp.h"
#include <xc.h>

#define RPM_ADC_CHANNEL 0x04

uint16_t get_rpm();
unsigned char *get_indicator_stat();
unsigned char *my_strcpy(unsigned char *dest, const unsigned char *src);

#endif	/* ECU2_SENSOR_H */

