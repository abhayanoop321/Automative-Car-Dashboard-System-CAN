/*
 * File:   main.c
 * Author: abhay
 *
 * Created on 12 May, 2026, 5:24 PM
 */


#include <xc.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#define _XTAL_FREQ 8000000

void init_config(void){
    init_can();
    init_clcd();
}

void main(void) {
    init_config();
    unsigned char speeds[4];
    unsigned char gear;
    unsigned char rpms[5];
    unsigned char indicator[6];
    uint16_t speed_id, gear_id, rpm_id, ind_id;
    uint16_t speed_len, gear_len, rpm_len, ind_len;
    while(1){
        can_receive(&speed_id, speeds, &speed_len);
        __delay_ms(50);
        can_receive(&gear_id, gear, &gear_len);
        __delay_ms(50);
        can_receive(&rpm_id, rpms, &rpm_len);
        __delay_ms(50);
        can_receive(&ind_id, indicator, &ind_len);
        __delay_ms(50);
        clcd_print("SPD RPM GEAR IND", LINE2(0));
        clcd_print(speeds, LINE2(0));
        clcd_print(rpms, LINE2(4));
        clcd_write(gear, LINE2(8));
        clcd_print(indicator, LINE2(11));
        
    }
}
